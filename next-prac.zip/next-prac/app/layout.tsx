import '../styles/globals.scss';
import Layout from '../src/layout/Layout';

export const metadata = {
  title: 'Dashboard UI',
  description: 'Next.js 14 App Router Dashboard',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Layout>{children}</Layout>
      </body>
    </html>
  );
}
