import "./Creative.scss";

import ProgressBar from "@/components/ProgressBar/ProgressBar";
import TextBar from "@/components/TextBar/TextBar";
import GenerateCopyButton from "@/components/GenerateCopyButton/GenerateCopyButton";
import ContentCard from "@/components/ContentCard/ContentCard";

const CreativePage = () => {
  return (
    <div className="creative-page">
      <div className="creative-section progress-wrapper">
        <ProgressBar
          steps={["Creative", "Content", "Preview", "Approve"]}
          activeIndex={2}
          completed={[0, 1]}
        />
      </div>

      <div className="creative-section">
        <TextBar
          label="Generate a short, authentic Instagram caption (30–50 words)…"
          showRegenerate
        />
      </div>

      <div className="creative-section row">
        <GenerateCopyButton />
      </div>

      <div className="creative-section">
        <ContentCard />
      </div>
    </div>
  );
};

export default CreativePage;
