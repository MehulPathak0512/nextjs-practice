import { Add } from "@mui/icons-material";

import "./NewCampaignButton.scss";

const NewCampaignButton = () => {
  return (
    <button className="new-campaign-btn">
      <Add sx={{ fontSize: 16, color: "#ffffff" }} />
      New Campaign
    </button>
  );
};

export default NewCampaignButton;
