
import styles from './ProgressBar.module.scss';

export default function ProgressBar({ steps = [], activeIndex = 0, completed = [] }) {
  return (
    <div className={styles.progress}>
      <div className={styles.markers}>
        {steps.map((step, idx) => (
          <div key={idx} className={styles.marker}>
            <div
              className={[
                styles.badge,
                completed.includes(idx) ? styles.completed : '',
                idx === activeIndex ? styles.active : '',
              ].join(' ')}
            >
              {completed.includes(idx) ? '✓' : 'x'}
            </div>
            <div className={styles.label}>{step}</div>

            {/* Connector only if not last */}
            {idx < steps.length - 1 && (
              <div
                className={[
                  styles.connector,
                  completed.includes(idx) ? styles.completed : '',
                ].join(' ')}
              ></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
