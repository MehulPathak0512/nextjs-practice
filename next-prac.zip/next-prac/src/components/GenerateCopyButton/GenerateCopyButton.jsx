'use client';

import styles from './GenerateCopyButton.module.scss';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import Cal from '../../assets/cal_icon.svg';
import copy from '../../assets/copy.svg';
import Image from 'next/image';
export default function GenerateCopyButton() {
  
  return (
    <>
    <div>
    <button className={styles.generateCopyBtn} >
      Generate the Copy
      <Image
          src={copy}
          alt="copy"
          width={24}
          height={24}
          className={styles.icon} // Optional: reuse or customize your styles
        />
    </button>

    <h3 className={styles.header}>
        <Image
          src={Cal}
          alt="Calendar icon"
          width={34}
          height={34}
          className={styles.icon} // Optional: reuse or customize your styles
        />
        Content
    </h3>
      </div>
    </>
  );
}