'use client';  

import ProgressBar from '../src/components/ProgressBar/ProgressBar';
import TextBar from '../src/components/TextBar/TextBar';
import GenerateCopyButton from '../src/components/GenerateCopyButton/GenerateCopyButton';
import ContentCard from '../src/components/ContentCard/ContentCard';

export default function Page() {
  return (
    <div className="container">
      <div className="card section">
        <ProgressBar steps={['Creative', 'Content', 'Preview', 'Approve']} activeIndex={2} completed={[0,1]} />
        
        <div className="spacer" />
        
        <TextBar
          label="Generate a short, authentic Instagram caption (around 30–50 words) that reflects the visual of a millennial man pausing at a Shell station with his coffee and phone. Emphasize the feeling of a seamless, connected everyday moment. Use words like ‘routine’, ‘connection’, ‘comfort’, and ‘journey.’"
          showRegenerate
        />

        <div className="spacer" />
        
        <div className="row">
          <GenerateCopyButton />
        </div>

        <div className="spacer" />
        <ContentCard />
      </div>
    </div>
  );
}
